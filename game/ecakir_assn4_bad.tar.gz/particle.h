#pragma once

#include "game.h"


class Particle{

    public:
        Particle();

        void rend(int x, int y);

        

    private:

    


        SDL_Texture* parType;

};