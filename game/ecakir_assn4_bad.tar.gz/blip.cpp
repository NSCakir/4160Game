#include "particle.h"
#include "game.h"
#include "blip.h"

Blip::Blip(){

}

void Blip::inputs(){

}

void Blip::move(){

}

void Blip::present(){

}

void Blip::show_blip(){
    
}