#include "ImageHandler.h"


SDL_Texture* ImageHandler::Load(const char* texture){
    
    SDL_Surface* tempSurface = IMG_Load(texture);
    Uint32 key = SDL_MapRGB(tempSurface->format, 255, 255, 255);
    SDL_SetColorKey( tempSurface, SDL_TRUE, key);
    SDL_Texture* tex = SDL_CreateTextureFromSurface(Game::renderer, tempSurface);
    SDL_FreeSurface(tempSurface);

    return tex;

}

void ImageHandler::Create(SDL_Texture* tex, SDL_Rect src, SDL_Rect dest){
    
    SDL_RenderCopy(Game::renderer, tex, &src, &dest);
}